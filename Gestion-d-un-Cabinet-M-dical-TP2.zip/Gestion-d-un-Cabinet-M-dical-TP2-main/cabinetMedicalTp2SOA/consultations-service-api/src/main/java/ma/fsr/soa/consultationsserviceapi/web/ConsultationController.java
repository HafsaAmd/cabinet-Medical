package ma.fsr.soa.consultationsserviceapi.web;

import ma.fsr.soa.cabinetrepo.model.Consultation;
import ma.fsr.soa.consultationsserviceapi.service.ConsultationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/consultations")
public class ConsultationController {

    @Autowired
    ConsultationService consultationService;

    @PostMapping
    public Consultation create(@RequestParam Long idRendezVous,
                               @RequestParam(required = false) String rapport,
                               @RequestParam(required = false) LocalDate dateConsultation) throws Exception {
        return consultationService.create(idRendezVous, dateConsultation, rapport);
    }

    @GetMapping
    public List<Consultation> list() {
        return consultationService.list();
    }

    @DeleteMapping("/{idConsultation}")
    public void delete(@PathVariable Long idConsultation) {
        consultationService.delete(idConsultation);
    }
}

