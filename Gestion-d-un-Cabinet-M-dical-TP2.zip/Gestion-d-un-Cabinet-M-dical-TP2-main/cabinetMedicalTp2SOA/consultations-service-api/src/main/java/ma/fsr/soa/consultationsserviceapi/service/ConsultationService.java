package ma.fsr.soa.consultationsserviceapi.service;

import ma.fsr.soa.cabinetrepo.model.Consultation;
import ma.fsr.soa.cabinetrepo.model.RendezVous;
import ma.fsr.soa.cabinetrepo.repository.ConsultationRepository;
import ma.fsr.soa.cabinetrepo.repository.RendezVousRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ConsultationService {

    @Autowired
    ConsultationRepository consultationRepository;

    @Autowired
    RendezVousRepository rendezVousRepository;

    public Consultation create(Long idRendezVous, LocalDate dateConsultation, String rapport) throws Exception {
        RendezVous rendezVous = rendezVousRepository.findById(idRendezVous).orElse(null);

        if (rendezVous == null) {
            throw new Exception("Rendez-vous introuvable.");
        }

        if (dateConsultation == null) {
            dateConsultation = LocalDate.now();
        }

        Consultation consultation = new Consultation(null, dateConsultation, rapport, rendezVous);
        return consultationRepository.save(consultation);
    }

    public List<Consultation> list() {
        return consultationRepository.findAll();
    }

    public void delete(Long idConsultation) {
        Consultation consultation = consultationRepository.findById(idConsultation).orElse(null);
        if (consultation != null) {
            consultationRepository.delete(consultation);
        }
    }
}

