package ma.fsr.soa.consultationsserviceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationsServiceApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
