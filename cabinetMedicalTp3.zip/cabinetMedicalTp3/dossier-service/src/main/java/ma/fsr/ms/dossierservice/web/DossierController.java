package ma.fsr.ms.dossierservice.web;

import ma.fsr.ms.dossierservice.dto.DossierPatientDto;
import ma.fsr.ms.dossierservice.service.DossierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/internal/api/v1/dossiers")
public class DossierController {

    @Autowired
    private DossierService dossierService;

    @GetMapping("/patient/{patientId}")
    public DossierPatientDto getDossierPatient(@PathVariable Long patientId) {
        return dossierService.getDossierPatient(patientId);
    }
}
