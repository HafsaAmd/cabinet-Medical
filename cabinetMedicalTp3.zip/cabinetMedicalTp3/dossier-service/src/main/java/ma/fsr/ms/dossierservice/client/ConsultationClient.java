package ma.fsr.ms.dossierservice.client;

import ma.fsr.ms.dossierservice.dto.ConsultationDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class ConsultationClient {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${consultation.service.url}")
    private String consultationServiceUrl;

    public List<ConsultationDto> getConsultationsByRendezVousId(Long rendezVousId) {
        try {
            ResponseEntity<List<ConsultationDto>> response = restTemplate.exchange(
                    consultationServiceUrl + "/internal/api/v1/consultations/rendezvous/" + rendezVousId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<ConsultationDto>>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la récupération des consultations pour le rendez-vous : " + rendezVousId);
        }
    }
}
