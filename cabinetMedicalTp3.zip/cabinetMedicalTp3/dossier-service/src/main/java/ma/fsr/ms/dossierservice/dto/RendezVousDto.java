package ma.fsr.ms.dossierservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RendezVousDto {
    private Long id;
    private LocalDateTime dateRdv;
    private Long patientId;
    private Long medecinId;
    private String statut;
}
