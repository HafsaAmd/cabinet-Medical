package ma.fsr.ms.dossierservice.client;

import ma.fsr.ms.dossierservice.dto.RendezVousDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class RendezVousClient {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${rendezvous.service.url}")
    private String rendezVousServiceUrl;

    public List<RendezVousDto> getRendezVousByPatientId(Long patientId) {
        try {
            ResponseEntity<List<RendezVousDto>> response = restTemplate.exchange(
                    rendezVousServiceUrl + "/internal/api/v1/rendezvous/patient/" + patientId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<RendezVousDto>>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la récupération des rendez-vous pour le patient : " + patientId);
        }
    }
}
