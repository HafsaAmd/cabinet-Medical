package ma.fsr.ms.dossierservice.client;

import ma.fsr.ms.dossierservice.dto.PatientDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class PatientClient {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${patient.service.url}")
    private String patientServiceUrl;

    public PatientDto getPatient(Long patientId) {
        try {
            return restTemplate.getForObject(
                    patientServiceUrl + "/internal/api/v1/patients/" + patientId,
                    PatientDto.class
            );
        } catch (Exception e) {
            throw new RuntimeException("Patient introuvable : id = " + patientId);
        }
    }
}
