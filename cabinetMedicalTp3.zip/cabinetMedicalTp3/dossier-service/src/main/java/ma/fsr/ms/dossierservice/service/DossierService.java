package ma.fsr.ms.dossierservice.service;

import ma.fsr.ms.dossierservice.client.ConsultationClient;
import ma.fsr.ms.dossierservice.client.PatientClient;
import ma.fsr.ms.dossierservice.client.RendezVousClient;
import ma.fsr.ms.dossierservice.dto.ConsultationDto;
import ma.fsr.ms.dossierservice.dto.DossierPatientDto;
import ma.fsr.ms.dossierservice.dto.PatientDto;
import ma.fsr.ms.dossierservice.dto.RendezVousDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DossierService {

    @Autowired
    private PatientClient patientClient;

    @Autowired
    private RendezVousClient rendezVousClient;

    @Autowired
    private ConsultationClient consultationClient;

    public DossierPatientDto getDossierPatient(Long patientId) {
        // Récupérer le patient
        PatientDto patient = patientClient.getPatient(patientId);

        // Récupérer les rendez-vous du patient
        List<RendezVousDto> rendezVous = rendezVousClient.getRendezVousByPatientId(patientId);

        // Récupérer les consultations pour chaque rendez-vous
        List<ConsultationDto> consultations = new ArrayList<>();
        for (RendezVousDto rdv : rendezVous) {
            try {
                List<ConsultationDto> consultationsRdv = consultationClient.getConsultationsByRendezVousId(rdv.getId());
                if (consultationsRdv != null) {
                    consultations.addAll(consultationsRdv);
                }
            } catch (Exception e) {
                // Ignorer les erreurs si pas de consultation pour ce rendez-vous
            }
        }

        return new DossierPatientDto(patient, rendezVous, consultations);
    }
}
