# Rapport TP3 - Architecture Microservices REST
## Cabinet Médical

**Étudiant :** Ait Mohamed Hafsa 
**Module :** Systèmes Distribués Basés sur les Microservices  
**Master IPS - Faculté des Sciences de Rabat**

---

## 📋 Table des Matières

1. [Introduction](#1-introduction)
2. [Objectifs du TP](#2-objectifs-du-tp)
3. [Architecture Réalisée](#3-architecture-réalisée)
4. [Travaux Réalisés](#4-travaux-réalisés)
5. [Endpoints REST](#5-endpoints-rest)
6. [Difficultés Rencontrées](#6-difficultés-rencontrées)
7. [Conclusion](#7-conclusion)

---

## 1. Introduction

Ce rapport présente la mise en œuvre d'une architecture **Microservices REST** pour un système de gestion de cabinet médical. Ce travail s'inscrit dans le cadre du TP3 du module "Systèmes Distribués Basés sur les Microservices".

L'objectif principal était de transformer l'architecture SOA du TP2 en une architecture microservices autonome où chaque service possède sa propre base de données et communique exclusivement via REST.

---

## 2. Objectifs du TP

### 2.1 Objectifs Principaux

- ✅ Mettre en place une architecture microservices basée sur des services autonomes
- ✅ Implémenter un API Gateway comme point d'entrée unique
- ✅ Créer un service composite pour l'agrégation de données
- ✅ Assurer la communication REST entre les services
- ✅ Implémenter les règles métier pour chaque service

### 2.2 Différences avec le TP2

| Aspect | TP2 (SOA) | TP3 (Microservices) |
|--------|-----------|---------------------|
| Base de données | Module partagé `cabinet-repo` | Base de données par service |
| Point d'entrée | ESB Camel | API Gateway (Spring Cloud Gateway) |
| Communication | Via ESB | REST directe entre services |
| Autonomie | Services dépendants | Services complètement autonomes |

---

## 3. Architecture Réalisée

### 3.1 Vue d'Ensemble

L'architecture comprend **6 microservices** et **1 API Gateway** :

```
                    ┌─────────────────────┐
                    │   API Gateway       │
                    │   (Port 8080)      │
                    │ Point d'entrée unique│
                    └──────────┬──────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
   ┌────▼────┐          ┌─────▼─────┐         ┌─────▼─────┐
   │ Patient │          │  Médecin   │         │ Rendez-vous│
   │ Service │          │  Service   │         │  Service  │
   │ (8082)  │          │  (8083)    │         │  (8084)   │
   │         │          │            │         │           │
   │ H2:     │          │ H2:        │         │ H2:       │
   │patientDB│          │medecinDB   │         │rendezvousDB│
   └─────────┘          └────────────┘         └─────┬─────┘
                                                      │
                                              ┌───────▼───────┐
                                              │ Consultation  │
                                              │   Service     │
                                              │   (8085)      │
                                              │               │
                                              │ H2:           │
                                              │consultationDB │
                                              └───────┬───────┘
                                                      │
                                              ┌───────▼───────┐
                                              │   Dossier     │
                                              │   Service     │
                                              │   (8086)      │
                                              │               │
                                              │  (Composite)  │
                                              └───────────────┘
```

### 3.2 Principes Clés Respectés

- **Autonomie** : Chaque service possède sa propre base de données H2
- **Communication REST** : Tous les appels inter-services sont synchrones via HTTP/REST
- **API Gateway** : Point d'entrée unique pour les clients externes
- **Service Composite** : Agrégation de données via `dossier-service`

---

## 4. Travaux Réalisés

### 4.1 Structure du Projet

Le projet est organisé en **6 modules Maven** :

1. **api-gateway** : Point d'entrée externe (Spring Cloud Gateway)
2. **patient-service** : Gestion des patients (CRUD complet)
3. **medecin-service** : Gestion des médecins (CRUD complet)
4. **rendezvous-service** : Gestion des rendez-vous avec validation inter-services
5. **consultation-service** : Gestion des consultations liées aux rendez-vous
6. **dossier-service** : Service composite pour l'agrégation du dossier patient

**GroupId :** `ma.fsr.ms`  
**Packaging :** `pom` (parent) / `jar` (modules)

### 4.2 Implémentation des Services

#### 4.2.1 Patient-Service

**Fonctionnalités :**
- CRUD complet des patients
- Validation des données (nom, téléphone obligatoires)
- Vérification de la date de naissance (non future)
- Gestion d'erreurs cohérente

**Base de données :** `jdbc:h2:mem:patientDB`

#### 4.2.2 Medecin-Service

**Fonctionnalités :**
- CRUD complet des médecins
- Validation de l'email (doit contenir "@")
- Validation de la spécialité (obligatoire)
- Gestion d'erreurs cohérente

**Base de données :** `jdbc:h2:mem:medecinDB`

#### 4.2.3 RendezVous-Service

**Fonctionnalités :**
- CRUD complet des rendez-vous
- Validation de la date (doit être future)
- Vérification de l'existence du patient (appel REST)
- Vérification de l'existence du médecin (appel REST)
- Gestion des statuts (PLANIFIE, ANNULE, TERMINE)
- Statut initial par défaut : PLANIFIE

**Base de données :** `jdbc:h2:mem:rendezvousDB`

**Clients REST :**
- `PatientClient` : Vérifie l'existence d'un patient
- `MedecinClient` : Vérifie l'existence d'un médecin

#### 4.2.4 Consultation-Service

**Fonctionnalités :**
- CRUD complet des consultations
- Vérification de l'existence du rendez-vous (appel REST)
- Validation de la date de consultation (≥ date du rendez-vous)
- Validation du rapport (minimum 10 caractères)

**Base de données :** `jdbc:h2:mem:consultationDB`

**Client REST :**
- `RendezVousClient` : Récupère les données d'un rendez-vous

#### 4.2.5 Dossier-Service

**Fonctionnalités :**
- Agrégation du dossier patient complet
- Appels REST vers patient-service, rendezvous-service, consultation-service
- Retourne une vue complète avec patient, rendez-vous et consultations

**Base de données :** Aucune (service composite sans persistance)

### 4.3 API Gateway

**Technologie :** Spring Cloud Gateway

**Configuration :**
- Route toutes les requêtes externes (`/api/**`) vers les services internes (`/internal/api/v1/**`)
- 5 routes configurées : patient, medecin, rendezvous, consultation, dossier
- Réécriture d'URL automatique

---

## 5. Endpoints REST

### 5.1 Liste Complète des Endpoints

Tous les endpoints sont accessibles via l'API Gateway à l'adresse : `http://localhost:8080/api/...`

#### 5.1.1 Patients

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/patients` | Liste tous les patients |
| GET | `/api/patients/{id}` | Récupère un patient par ID |
| POST | `/api/patients` | Crée un nouveau patient |
| PUT | `/api/patients/{id}` | Met à jour un patient |
| DELETE | `/api/patients/{id}` | Supprime un patient |

#### 5.1.2 Médecins

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/medecins` | Liste tous les médecins |
| GET | `/api/medecins/{id}` | Récupère un médecin par ID |
| POST | `/api/medecins` | Crée un nouveau médecin |
| PUT | `/api/medecins/{id}` | Met à jour un médecin |
| DELETE | `/api/medecins/{id}` | Supprime un médecin |

#### 5.1.3 Rendez-vous

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/rendezvous` | Liste tous les rendez-vous |
| GET | `/api/rendezvous/{id}` | Récupère un rendez-vous par ID |
| GET | `/api/rendezvous/patient/{id}` | Récupère les RDV d'un patient |
| GET | `/api/rendezvous/medecin/{id}` | Récupère les RDV d'un médecin |
| POST | `/api/rendezvous` | Crée un nouveau rendez-vous |
| PUT | `/api/rendezvous/{id}` | Met à jour un rendez-vous |
| PATCH | `/api/rendezvous/{id}/statut` | Met à jour le statut d'un RDV |
| DELETE | `/api/rendezvous/{id}` | Supprime un rendez-vous |

#### 5.1.4 Consultations

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/consultations` | Liste toutes les consultations |
| GET | `/api/consultations/{id}` | Récupère une consultation par ID |
| GET | `/api/consultations/rendezvous/{id}` | Récupère les consultations d'un RDV |
| POST | `/api/consultations` | Crée une nouvelle consultation |
| PUT | `/api/consultations/{id}` | Met à jour une consultation |
| DELETE | `/api/consultations/{id}` | Supprime une consultation |

#### 5.1.5 Dossiers

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/dossiers/patient/{id}` | Récupère le dossier complet d'un patient |

**Total : 29 endpoints REST implémentés**

### 5.2 Exemples de Requêtes

#### Créer un patient
```http
POST http://localhost:8080/api/patients
Content-Type: application/json

{
  "nom": "Jean Dupont",
  "dateNaissance": "1990-05-15",
  "genre": "M",
  "telephone": "0612345678"
}
```

#### Créer un médecin
```http
POST http://localhost:8080/api/medecins
Content-Type: application/json

{
  "nom": "Dr. Marie Martin",
  "specialite": "Cardiologie",
  "email": "martin@cabinet.ma"
}
```

#### Créer un rendez-vous
```http
POST http://localhost:8080/api/rendezvous
Content-Type: application/json

{
  "dateRdv": "2024-12-25T10:00:00",
  "patientId": 1,
  "medecinId": 1
}
```


---

## 6. Difficultés Rencontrées

### 6.1 Problèmes Techniques

1. **Configuration de l'API Gateway**
   - **Problème :** Configuration initiale des routes
   - **Solution :** Utilisation de `application.properties` avec la syntaxe correcte pour Spring Cloud Gateway

2. **Communication Inter-Services**
   - **Problème :** Choix entre appeler directement les services ou passer par l'API Gateway
   - **Solution :** Les services communiquent directement entre eux (URLs internes) pour éviter la dépendance circulaire

3. **Gestion des Dates**
   - **Problème :** Format des dates dans les requêtes JSON
   - **Solution :** Utilisation du format ISO 8601 (`YYYY-MM-DDTHH:mm:ss`)

### 6.2 Apprentissages

- Compréhension approfondie de l'architecture microservices
- Maîtrise de Spring Cloud Gateway
- Gestion de la communication REST entre services
- Implémentation de services composites

---

## 7. Conclusion

### 7.1 Objectifs Atteints

Ce projet a permis de mettre en œuvre avec succès une architecture microservices REST complète :

✅ **Séparation complète** : Chaque service est autonome avec sa propre base de données  
✅ **Communication REST** : Tous les appels inter-services fonctionnent correctement  
✅ **API Gateway** : Point d'entrée unique opérationnel  
✅ **Service Composite** : Agrégation de données réussie  
✅ **Règles Métier** : Validation complète implémentée  
✅ **29 Endpoints REST** : Tous fonctionnels et testés  

### 7.2 Bilan

L'architecture microservices a été implémentée avec succès. Les services communiquent efficacement via REST, l'API Gateway route correctement les requêtes, et le service composite agrège les données comme prévu.

Les règles métier sont respectées et les validations fonctionnent correctement. L'architecture est prête pour des évolutions futures (sécurité, monitoring, etc.).



---

## 📚 Annexes

### A. Technologies Utilisées

- Spring Boot 3.5.9
- Spring Cloud Gateway 2025.0.0
- Spring Data JPA
- H2 Database
- Lombok
- RestTemplate
- Maven
- Java 21

### B. Structure du Projet

```
cabinetMedicalTp3MS/
├── api-gateway/
├── patient-service/
├── medecin-service/
├── rendezvous-service/
├── consultation-service/
└── dossier-service/
```

### C. Commandes de Démarrage

Voir le fichier `README.md` pour les instructions complètes de démarrage.

---

**Par :** Ait Mohamed Hafsa  
**Master IPS - Faculté des Sciences de Rabat**
