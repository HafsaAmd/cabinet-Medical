package ma.fsr.ms.rendezvousservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RendezvousServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RendezvousServiceApplication.class, args);
    }

}
