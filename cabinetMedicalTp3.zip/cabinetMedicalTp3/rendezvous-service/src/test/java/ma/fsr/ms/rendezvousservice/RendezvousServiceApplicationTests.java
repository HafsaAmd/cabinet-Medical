package ma.fsr.ms.rendezvousservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RendezvousServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
