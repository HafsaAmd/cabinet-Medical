package ma.fsr.ms.consultationservice.service;

import ma.fsr.ms.consultationservice.client.RendezVous;
import ma.fsr.ms.consultationservice.client.RendezVousClient;
import ma.fsr.ms.consultationservice.model.Consultation;
import ma.fsr.ms.consultationservice.repository.ConsultationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ConsultationService {

    @Autowired
    private ConsultationRepository consultationRepository;

    @Autowired
    private RendezVousClient rendezVousClient;

    public Consultation create(Consultation consultation) throws Exception {
        // Vérifier que le rendez-vous existe
        RendezVous rendezVous = rendezVousClient.getRendezVous(consultation.getRendezVousId());
        if (rendezVous == null) {
            throw new Exception("Rendez-vous introuvable.");
        }

        // La date de consultation est obligatoire
        if (consultation.getDateConsultation() == null) {
            throw new Exception("La date de consultation est obligatoire.");
        }

        // La date de consultation doit être >= à la date du rendez-vous
        if (consultation.getDateConsultation().isBefore(rendezVous.getDateRdv())) {
            throw new Exception("Date de consultation invalide.");
        }

        // Le rapport est obligatoire (au moins 10 caractères)
        if (consultation.getRapport() == null || consultation.getRapport().trim().length() < 10) {
            throw new Exception("Rapport de consultation insuffisant.");
        }

        return consultationRepository.save(consultation);
    }

    public Consultation update(Consultation consultation) throws Exception {
        Optional<Consultation> c = consultationRepository.findById(consultation.getId());
        if (!c.isPresent()) {
            throw new Exception("Consultation introuvable");
        }

        Consultation existing = c.get();

        // Si le rendez-vous est modifié, vérifier qu'il existe
        if (consultation.getRendezVousId() != null && 
            !consultation.getRendezVousId().equals(existing.getRendezVousId())) {
            RendezVous rendezVous = rendezVousClient.getRendezVous(consultation.getRendezVousId());
            if (rendezVous == null) {
                throw new Exception("Rendez-vous introuvable.");
            }
            existing.setRendezVousId(consultation.getRendezVousId());
        }

        // Si la date est modifiée, vérifier qu'elle est >= date du rendez-vous
        if (consultation.getDateConsultation() != null) {
            RendezVous rendezVous = rendezVousClient.getRendezVous(
                consultation.getRendezVousId() != null ? 
                consultation.getRendezVousId() : existing.getRendezVousId()
            );
            if (consultation.getDateConsultation().isBefore(rendezVous.getDateRdv())) {
                throw new Exception("Date de consultation invalide.");
            }
            existing.setDateConsultation(consultation.getDateConsultation());
        }

        // Mettre à jour les autres champs
        if (consultation.getDiagnostic() != null) {
            existing.setDiagnostic(consultation.getDiagnostic());
        }
        if (consultation.getPrescription() != null) {
            existing.setPrescription(consultation.getPrescription());
        }
        if (consultation.getRapport() != null) {
            if (consultation.getRapport().trim().length() < 10) {
                throw new Exception("Rapport de consultation insuffisant.");
            }
            existing.setRapport(consultation.getRapport());
        }

        return consultationRepository.save(existing);
    }

    public Consultation getConsultation(Long id) throws Exception {
        Optional<Consultation> consultation = consultationRepository.findById(id);
        if (consultation.isEmpty()) {
            throw new Exception("Consultation introuvable : id = " + id);
        }
        return consultation.get();
    }

    public List<Consultation> list() {
        return consultationRepository.findAll();
    }

    public List<Consultation> getByRendezVousId(Long rendezVousId) {
        return consultationRepository.findByRendezVousId(rendezVousId);
    }

    public void delete(Long id) {
        Consultation consultation = consultationRepository.findById(id).orElse(null);
        if (consultation != null) {
            consultationRepository.delete(consultation);
        }
    }
}
