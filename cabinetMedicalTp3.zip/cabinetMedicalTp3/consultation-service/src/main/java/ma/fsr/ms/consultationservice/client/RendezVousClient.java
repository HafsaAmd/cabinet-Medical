package ma.fsr.ms.consultationservice.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RendezVousClient {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${rendezvous.service.url}")
    private String rendezVousServiceUrl;

    public RendezVous getRendezVous(Long rendezVousId) {
        try {
            return restTemplate.getForObject(
                    rendezVousServiceUrl + "/internal/api/v1/rendezvous/" + rendezVousId,
                    RendezVous.class
            );
        } catch (Exception e) {
            throw new RuntimeException("Rendez-vous introuvable.");
        }
    }
}
