package ma.fsr.ms.consultationservice.client;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class RendezVous {
    private Long id;
    private LocalDateTime dateRdv;
    private Long patientId;
    private Long medecinId;
    private String statut;
}
