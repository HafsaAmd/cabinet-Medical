package ma.fsr.ms.consultationservice.web;

import ma.fsr.ms.consultationservice.model.Consultation;
import ma.fsr.ms.consultationservice.service.ConsultationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/consultations")
public class ConsultationController {

    @Autowired
    private ConsultationService consultationService;

    @PostMapping
    public Consultation create(@RequestBody Consultation consultation) throws Exception {
        return consultationService.create(consultation);
    }

    @GetMapping("/{id}")
    public Consultation get(@PathVariable Long id) throws Exception {
        return consultationService.getConsultation(id);
    }

    @GetMapping
    public List<Consultation> list() {
        return consultationService.list();
    }

    @GetMapping("/rendezvous/{rendezVousId}")
    public List<Consultation> getByRendezVousId(@PathVariable Long rendezVousId) {
        return consultationService.getByRendezVousId(rendezVousId);
    }

    @PutMapping("/{id}")
    public Consultation update(@PathVariable Long id, @RequestBody Consultation consultation) throws Exception {
        consultation.setId(id);
        return consultationService.update(consultation);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        consultationService.delete(id);
    }
}
