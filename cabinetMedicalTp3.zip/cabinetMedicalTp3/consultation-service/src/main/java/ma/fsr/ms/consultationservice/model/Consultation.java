package ma.fsr.ms.consultationservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consultation {
    @Id
    @GeneratedValue
    private Long id;
    
    private Long rendezVousId;
    private LocalDateTime dateConsultation;
    private String diagnostic;
    private String prescription;
    private String rapport;
}
