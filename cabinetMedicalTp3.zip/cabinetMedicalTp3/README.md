# TP3 - Architecture Microservices REST
## Cabinet Médical - Mise en œuvre d'une architecture Microservices

**Auteur :** [Votre Nom]  
**Date :** 2024  
**Module :** Systèmes Distribués Basés sur les Microservices  
**Master IPS - Faculté des Sciences de Rabat**

---

## 📋 Table des Matières

1. [Introduction](#introduction)
2. [Architecture du Projet](#architecture-du-projet)
3. [Structure du Projet](#structure-du-projet)
4. [Microservices Implémentés](#microservices-implémentés)
5. [API Gateway](#api-gateway)
6. [Endpoints REST](#endpoints-rest)
7. [Tests et Captures](#tests-et-captures)
8. [Technologies Utilisées](#technologies-utilisées)
9. [Installation et Démarrage](#installation-et-démarrage)
10. [Conclusion](#conclusion)

---

## 1. Introduction

Ce projet présente la mise en œuvre d'une architecture **Microservices REST** pour un système de gestion de cabinet médical. L'objectif principal est de transformer l'architecture SOA du TP2 en une architecture microservices autonome où chaque service possède sa propre base de données et communique via REST.

### Objectifs Réalisés

- ✅ Séparation complète des services (fin du module `cabinet-repo` partagé)
- ✅ Base de données par service (autonomie complète)
- ✅ Communication REST synchrone entre services
- ✅ API Gateway comme point d'entrée unique
- ✅ Service composite pour l'agrégation de données
- ✅ Implémentation des règles métier pour chaque service

---

## 2. Architecture du Projet

### 2.1 Vue d'Ensemble

L'architecture comprend **6 microservices** et **1 API Gateway** :

```
┌─────────────────────────────────────────────────────────┐
│                    API Gateway (8080)                   │
│              Point d'entrée externe unique               │
└─────────────────────────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   Patient    │  │   Médecin    │  │  Rendez-vous │
│  Service     │  │   Service    │  │   Service    │
│   (8082)     │  │   (8083)     │  │   (8084)     │
│              │  │              │  │              │
│  H2:patientDB│  │ H2:medecinDB │  │H2:rendezvousDB│
└──────────────┘  └──────────────┘  └──────────────┘
                                              │
                                              ▼
                                    ┌──────────────┐
                                    │ Consultation │
                                    │   Service    │
                                    │   (8085)     │
                                    │              │
                                    │H2:consultationDB│
                                    └──────────────┘
                                              │
                                              ▼
                                    ┌──────────────┐
                                    │   Dossier    │
                                    │   Service    │
                                    │   (8086)     │
                                    │              │
                                    │  (Composite) │
                                    └──────────────┘
```

### 2.2 Principes Clés

- **Autonomie** : Chaque service possède sa propre base de données
- **Communication REST** : Appels synchrones via HTTP/REST
- **API Gateway** : Point d'entrée unique pour les clients externes
- **Service Composite** : Agrégation de données via `dossier-service`

---

## 3. Structure du Projet

### 3.1 Modules Maven

```
cabinetMedicalTp3MS/
├── api-gateway/              # Point d'entrée externe
├── patient-service/           # Gestion des patients
├── medecin-service/          # Gestion des médecins
├── rendezvous-service/       # Gestion des rendez-vous
├── consultation-service/     # Gestion des consultations
└── dossier-service/          # Service composite (agrégation)
```

### 3.2 GroupId et Packaging

- **GroupId :** `ma.fsr.ms`
- **Packaging :** `pom` (parent) / `jar` (modules)
- **Version Java :** 21
- **Spring Boot :** 3.5.9
- **Spring Cloud :** 2025.0.0

---

## 4. Microservices Implémentés

### 4.1 Patient-Service (Port 8082)

**Responsabilité :** Gestion complète des patients (CRUD)

**Base de données :** `jdbc:h2:mem:patientDB`

**Règles Métier :**
- Le nom est obligatoire
- Le téléphone est obligatoire
- La date de naissance ne peut pas être dans le futur
- Validation des données avant persistance

**Packages :**
- `ma.fsr.ms.patientservice.model` : Entité Patient
- `ma.fsr.ms.patientservice.repository` : PatientRepository
- `ma.fsr.ms.patientservice.service` : PatientService
- `ma.fsr.ms.patientservice.web` : PatientController
- `ma.fsr.ms.patientservice.exception` : Gestion des erreurs

---

### 4.2 Medecin-Service (Port 8083)

**Responsabilité :** Gestion complète des médecins (CRUD)

**Base de données :** `jdbc:h2:mem:medecinDB`

**Règles Métier :**
- Le nom est obligatoire
- L'email est obligatoire et doit contenir "@"
- La spécialité est obligatoire
- Validation des informations professionnelles

**Packages :**
- `ma.fsr.ms.medecinservice.model` : Entité Medecin
- `ma.fsr.ms.medecinservice.repository` : MedecinRepository
- `ma.fsr.ms.medecinservice.service` : MedecinService
- `ma.fsr.ms.medecinservice.web` : MedecinController
- `ma.fsr.ms.medecinservice.exception` : Gestion des erreurs

---

### 4.3 RendezVous-Service (Port 8084)

**Responsabilité :** Gestion des rendez-vous avec validation inter-services

**Base de données :** `jdbc:h2:mem:rendezvousDB`

**Règles Métier :**
- La date du rendez-vous doit être future
- Le patient doit exister (vérification via REST)
- Le médecin doit exister (vérification via REST)
- Statuts autorisés : PLANIFIE, ANNULE, TERMINE
- Statut initial par défaut : PLANIFIE

**Clients REST :**
- `PatientClient` : Vérifie l'existence d'un patient
- `MedecinClient` : Vérifie l'existence d'un médecin

**Packages :**
- `ma.fsr.ms.rendezvousservice.model` : RendezVous, StatutRdv (enum)
- `ma.fsr.ms.rendezvousservice.repository` : RendezVousRepository
- `ma.fsr.ms.rendezvousservice.service` : RendezVousService
- `ma.fsr.ms.rendezvousservice.web` : RendezVousController
- `ma.fsr.ms.rendezvousservice.client` : Clients REST

---

### 4.4 Consultation-Service (Port 8085)

**Responsabilité :** Gestion des consultations liées aux rendez-vous

**Base de données :** `jdbc:h2:mem:consultationDB`

**Règles Métier :**
- Le rendez-vous doit exister (vérification via REST)
- La date de consultation est obligatoire
- La date de consultation doit être ≥ à la date du rendez-vous
- Le rapport est obligatoire (minimum 10 caractères)

**Client REST :**
- `RendezVousClient` : Vérifie l'existence et récupère les données d'un rendez-vous

**Packages :**
- `ma.fsr.ms.consultationservice.model` : Consultation
- `ma.fsr.ms.consultationservice.repository` : ConsultationRepository
- `ma.fsr.ms.consultationservice.service` : ConsultationService
- `ma.fsr.ms.consultationservice.web` : ConsultationController
- `ma.fsr.ms.consultationservice.client` : Client REST

---

### 4.5 Dossier-Service (Port 8086)

**Responsabilité :** Service composite pour l'agrégation du dossier patient

**Base de données :** Aucune (service composite sans persistance)

**Fonctionnalité :**
- Agrège les données du patient, ses rendez-vous et consultations
- Appels REST vers : patient-service, rendezvous-service, consultation-service
- Retourne une vue complète du dossier patient

**Packages :**
- `ma.fsr.ms.dossierservice.web` : DossierController
- `ma.fsr.ms.dossierservice.service` : DossierService
- `ma.fsr.ms.dossierservice.client` : Clients REST (Patient, RendezVous, Consultation)
- `ma.fsr.ms.dossierservice.dto` : DTOs pour l'agrégation

---

## 5. API Gateway

**Port :** 8080  
**Technologie :** Spring Cloud Gateway

### 5.1 Rôle

L'API Gateway sert de **point d'entrée unique** pour tous les clients externes. Elle :
- Route les requêtes vers les services appropriés
- Réécrit les URLs externes (`/api/**`) vers les URLs internes (`/internal/api/v1/**`)
- Centralise la gestion des accès (préparation pour sécurité future)

### 5.2 Routes Configurées

| Route | URI Cible | Path Externe | Path Interne |
|-------|-----------|--------------|---------------|
| patient | http://localhost:8082 | `/api/patients/**` | `/internal/api/v1/patients/**` |
| medecin | http://localhost:8083 | `/api/medecins/**` | `/internal/api/v1/medecins/**` |
| rendezvous | http://localhost:8084 | `/api/rendezvous/**` | `/internal/api/v1/rendezvous/**` |
| consultation | http://localhost:8085 | `/api/consultations/**` | `/internal/api/v1/consultations/**` |
| dossier | http://localhost:8086 | `/api/dossiers/**` | `/internal/api/v1/dossiers/**` |

---

## 6. Endpoints REST

### 6.1 Patients (via API Gateway)

**Base URL :** `http://localhost:8080/api/patients`

| Méthode | Endpoint | Description | Exemple |
|---------|----------|-------------|---------|
| GET | `/api/patients` | Liste tous les patients | `GET /api/patients` |
| GET | `/api/patients/{id}` | Récupère un patient par ID | `GET /api/patients/1` |
| POST | `/api/patients` | Crée un nouveau patient | `POST /api/patients` |
| PUT | `/api/patients/{id}` | Met à jour un patient | `PUT /api/patients/1` |
| DELETE | `/api/patients/{id}` | Supprime un patient | `DELETE /api/patients/1` |

**Exemple de Body (POST/PUT) :**
```json
{
  "nom": "Dupont",
  "dateNaissance": "1990-05-15",
  "genre": "M",
  "telephone": "0612345678"
}
```

---

### 6.2 Médecins (via API Gateway)

**Base URL :** `http://localhost:8080/api/medecins`

| Méthode | Endpoint | Description | Exemple |
|---------|----------|-------------|---------|
| GET | `/api/medecins` | Liste tous les médecins | `GET /api/medecins` |
| GET | `/api/medecins/{id}` | Récupère un médecin par ID | `GET /api/medecins/1` |
| POST | `/api/medecins` | Crée un nouveau médecin | `POST /api/medecins` |
| PUT | `/api/medecins/{id}` | Met à jour un médecin | `PUT /api/medecins/1` |
| DELETE | `/api/medecins/{id}` | Supprime un médecin | `DELETE /api/medecins/1` |

**Exemple de Body (POST/PUT) :**
```json
{
  "nom": "Martin",
  "specialite": "Cardiologie",
  "email": "martin@cabinet.ma"
}
```

---

### 6.3 Rendez-vous (via API Gateway)

**Base URL :** `http://localhost:8080/api/rendezvous`

| Méthode | Endpoint | Description | Exemple |
|---------|----------|-------------|---------|
| GET | `/api/rendezvous` | Liste tous les rendez-vous | `GET /api/rendezvous` |
| GET | `/api/rendezvous/{id}` | Récupère un RDV par ID | `GET /api/rendezvous/1` |
| GET | `/api/rendezvous/patient/{id}` | RDV d'un patient | `GET /api/rendezvous/patient/1` |
| GET | `/api/rendezvous/medecin/{id}` | RDV d'un médecin | `GET /api/rendezvous/medecin/1` |
| POST | `/api/rendezvous` | Crée un nouveau RDV | `POST /api/rendezvous` |
| PUT | `/api/rendezvous/{id}` | Met à jour un RDV | `PUT /api/rendezvous/1` |
| PATCH | `/api/rendezvous/{id}/statut` | Met à jour le statut | `PATCH /api/rendezvous/1/statut?statut=TERMINE` |
| DELETE | `/api/rendezvous/{id}` | Supprime un RDV | `DELETE /api/rendezvous/1` |

**Exemple de Body (POST/PUT) :**
```json
{
  "dateRdv": "2024-12-20T10:00:00",
  "patientId": 1,
  "medecinId": 1,
  "statut": "PLANIFIE"
}
```

**Statuts possibles :** `PLANIFIE`, `ANNULE`, `TERMINE`

---

### 6.4 Consultations (via API Gateway)

**Base URL :** `http://localhost:8080/api/consultations`

| Méthode | Endpoint | Description | Exemple |
|---------|----------|-------------|---------|
| GET | `/api/consultations` | Liste toutes les consultations | `GET /api/consultations` |
| GET | `/api/consultations/{id}` | Récupère une consultation | `GET /api/consultations/1` |
| GET | `/api/consultations/rendezvous/{id}` | Consultations d'un RDV | `GET /api/consultations/rendezvous/1` |
| POST | `/api/consultations` | Crée une consultation | `POST /api/consultations` |
| PUT | `/api/consultations/{id}` | Met à jour une consultation | `PUT /api/consultations/1` |
| DELETE | `/api/consultations/{id}` | Supprime une consultation | `DELETE /api/consultations/1` |

**Exemple de Body (POST/PUT) :**
```json
{
  "rendezVousId": 1,
  "dateConsultation": "2024-12-20T10:30:00",
  "diagnostic": "Hypertension artérielle",
  "prescription": "Médicament X, 1 comprimé par jour",
  "rapport": "Le patient présente des signes d'hypertension. Traitement prescrit."
}
```

---

### 6.5 Dossiers (via API Gateway)

**Base URL :** `http://localhost:8080/api/dossiers`

| Méthode | Endpoint | Description | Exemple |
|---------|----------|-------------|---------|
| GET | `/api/dossiers/patient/{id}` | Dossier complet d'un patient | `GET /api/dossiers/patient/1` |

**Réponse :**
```json
{
  "patient": {
    "id": 1,
    "nom": "Dupont",
    "dateNaissance": "1990-05-15",
    "genre": "M",
    "telephone": "0612345678"
  },
  "rendezVous": [
    {
      "id": 1,
      "dateRdv": "2024-12-20T10:00:00",
      "patientId": 1,
      "medecinId": 1,
      "statut": "TERMINE"
    }
  ],
  "consultations": [
    {
      "id": 1,
      "rendezVousId": 1,
      "dateConsultation": "2024-12-20T10:30:00",
      "diagnostic": "Hypertension artérielle",
      "prescription": "Médicament X",
      "rapport": "Le patient présente des signes d'hypertension..."
    }
  ]
}
```

---

## 7. Tests et Captures

### 7.1 Commandes cURL pour les Tests

Un fichier `TESTS_CURL.md` est disponible avec toutes les commandes de test.

### 7.2 Captures d'Écran Requises

Pour documenter les tests, veuillez inclure des captures d'écran de :

1. **GET /api/patients** - Liste des patients
2. **POST /api/patients** - Création d'un patient
3. **GET /api/patients/{id}** - Récupération d'un patient
4. **GET /api/medecins** - Liste des médecins
5. **POST /api/medecins** - Création d'un médecin
6. **POST /api/rendezvous** - Création d'un rendez-vous
7. **GET /api/dossiers/patient/{id}** - Dossier patient complet

### 7.3 Outils Recommandés

- **Postman** : Pour tester les endpoints REST
- **cURL** : Pour les tests en ligne de commande
- **Swagger/OpenAPI** : (Optionnel) Pour la documentation interactive

---

## 8. Technologies Utilisées

### 8.1 Framework et Bibliothèques

- **Spring Boot 3.5.9** : Framework principal
- **Spring Cloud Gateway 2025.0.0** : API Gateway
- **Spring Data JPA** : Accès aux données
- **H2 Database** : Base de données en mémoire
- **Lombok** : Réduction du code boilerplate
- **RestTemplate** : Client REST pour communication inter-services

### 8.2 Outils de Développement

- **Maven** : Gestion des dépendances et build
- **Java 21** : Langage de programmation
- **Git** : Contrôle de version

---

## 9. Installation et Démarrage

### 9.1 Prérequis

- Java 21 ou supérieur
- Maven 3.6+
- IDE (IntelliJ IDEA, Eclipse, VS Code)

### 9.2 Installation

```bash
# Cloner le projet
git clone [URL_DU_REPO]
cd cabinetMedicalTp3

# Compiler le projet
mvn clean install
```

### 9.3 Démarrage des Services

**Ordre de démarrage recommandé :**

1. **Patient-Service** (Port 8082)
```bash
cd patient-service
mvn spring-boot:run
```

2. **Medecin-Service** (Port 8083)
```bash
cd medecin-service
mvn spring-boot:run
```

3. **RendezVous-Service** (Port 8084)
```bash
cd rendezvous-service
mvn spring-boot:run
```

4. **Consultation-Service** (Port 8085)
```bash
cd consultation-service
mvn spring-boot:run
```

5. **Dossier-Service** (Port 8086)
```bash
cd dossier-service
mvn spring-boot:run
```

6. **API Gateway** (Port 8080)
```bash
cd api-gateway
mvn spring-boot:run
```

### 9.4 Vérification

Une fois tous les services démarrés, vérifiez que l'API Gateway répond :

```bash
curl http://localhost:8080/api/patients
```

---

## 10. Conclusion

### 10.1 Objectifs Atteints

Ce projet a permis de mettre en œuvre avec succès une architecture microservices REST complète :

✅ **Séparation complète** : Chaque service est autonome avec sa propre base de données  
✅ **Communication REST** : Appels synchrones entre services  
✅ **API Gateway** : Point d'entrée unique fonctionnel  
✅ **Service Composite** : Agrégation de données réussie  
✅ **Règles Métier** : Validation complète implémentée  
✅ **Gestion d'Erreurs** : Traitement cohérent des exceptions  

### 10.2 Apprentissages

- Architecture microservices et ses avantages
- Communication inter-services via REST
- Rôle et configuration d'un API Gateway
- Patterns de service composite et agrégation
- Gestion de bases de données distribuées

### 10.3 Perspectives d'Amélioration

- Ajout de la sécurité (JWT, OAuth2)
- Implémentation de la découverte de services (Eureka)
- Ajout de la résilience (Circuit Breaker, Retry)
- Monitoring et logging distribués
- Tests d'intégration automatisés

---

## 📚 Références

- Documentation Spring Cloud Gateway : https://spring.io/projects/spring-cloud-gateway
- Documentation Spring Boot : https://spring.io/projects/spring-boot
- Architecture Microservices : Patterns et bonnes pratiques

---

**Auteur :** [Votre Nom]  
**Date :** 2024  
**Master IPS - Faculté des Sciences de Rabat**
