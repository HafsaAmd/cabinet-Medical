package ma.fsr.ms.patientservice.web;

import ma.fsr.ms.patientservice.model.Patient;
import ma.fsr.ms.patientservice.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @PostMapping
    public Patient create(@RequestBody Patient patient) throws Exception {
        return patientService.create(patient);
    }

    @GetMapping("/{id}")
    public Patient get(@PathVariable Long id) throws Exception {
        return patientService.getPatient(id);
    }

    @GetMapping
    public List<Patient> list() {
        return patientService.list();
    }

    @PutMapping("/{id}")
    public Patient update(@PathVariable Long id, @RequestBody Patient patient) throws Exception {
        patient.setId(id);
        return patientService.update(patient);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) throws Exception {
        patientService.delete(id);
    }
}

